package com.example.fast_gpa_calculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
